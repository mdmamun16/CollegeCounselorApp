package com.example.collegecounselor

data class Question( var theQuestion: String,var theAnswer:ArrayList<String>)

