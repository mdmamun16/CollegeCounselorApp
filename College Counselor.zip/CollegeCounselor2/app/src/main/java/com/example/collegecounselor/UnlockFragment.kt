package com.example.collegecounselor


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import com.example.collegecounselor.databinding.FragmentUnlockBinding

/**
 * A simple [Fragment] subclass.
 */
class UnlockFragment : Fragment() {

    lateinit var binding :FragmentUnlockBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_unlock, container, false)

        binding=DataBindingUtil.inflate(inflater,R.layout.fragment_unlock,container,false)
        binding.levelButton1.setOnClickListener{
            Navigation.findNavController(it).navigate(R.id.action_unlockFragment_to_rulesFragment)
        }
        return binding.root
    }


}
