package com.example.collegecounselor


import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isInvisible
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import com.example.collegecounselor.databinding.FragmentLoginBinding
import com.example.collegecounselor.databinding.FragmentQuizBinding
import kotlinx.android.synthetic.main.fragment_quiz.*

/**
 * A simple [Fragment] subclass.
 */
class QuizFragment : Fragment() {
    lateinit var binding: FragmentQuizBinding
    lateinit var CurrentQuestion: Question
    private var questionIndex = 0
    val maxNumberOfQuestion = 8
    private var Score = 0
    lateinit var Answers: ArrayList<String>
    lateinit var selectedAnswers: String
    var questionNumber: String = "0"
    var Scoreall: Int = 0
    var textscore: String = "0"
    var usedhint: Int = 0

    var questions = arrayListOf<Question>(
        Question(
            "Which is the Independence day of Bangladesh?",
            arrayListOf("26 March", "21 Feb", "14th April", "16 December")
        ),
        Question(
            "Who is the first man landed on moon?",
            arrayListOf("Neil Armstrong", "Edwin Aldrin", "Michael Collins", "Yuri Gregory")
        ),
        Question(
            "Socrates is best known for - ",
            arrayListOf("Philosophy", "Mathmetics", "Physiology", "Astrology")
        ),
        Question(
            "How many states does USA have? ",
            arrayListOf("50", "45", "55", "49")
        ),
        Question(
            "Which is not an Europian Country? ",
            arrayListOf("Combodia", "Estonia", "Lithunia", "Moldova")
        ),
        Question(
            "Who is the first President of USA? ",
            arrayListOf(
                "George Washington",
                "William Henry Harrison",
                "Abraham Lincoln",
                "Franklin D. Roosevelt"
            )
        ),
        Question(
            "Which one is the largest ocean? ",
            arrayListOf("Pacific", "Atlantic", "Mediterian", "Arctic")
        ),
        Question(
            "What country has a town named Marathon? ",
            arrayListOf("USA", "GREECE", "ITALY", "FRANCE")
        ),
        Question(
            "What well-known mountain pass connects Pakistan and Afghanistan? ",
            arrayListOf("Khyber Pass", "Malakand Pass", "Ahmad Pass", "Shandar Pass")
        ),
        Question(
            "What country was formerly known as Ceylon?",
            arrayListOf("Sri Lanka", "Sweden", "Vietnam", "Switzerland")
        )
    )

    private fun SetQuestion() {
        binding.hintBut.visibility = if (view?.visibility == View.INVISIBLE) {
            View.VISIBLE
        } else {
            View.VISIBLE
        }

        binding.hintBut.visibility = if (usedhint == 2) {
            View.INVISIBLE
        } else {
            View.VISIBLE
        }

        binding.Button1.setBackgroundResource(R.drawable.btnyellow);
        binding.Button2.setBackgroundResource(R.drawable.btnyellow);
        binding.Button3.setBackgroundResource(R.drawable.btnyellow);
        binding.Button4.setBackgroundResource(R.drawable.btnyellow);
        questionNumber = (questionIndex + 1).toString()

        CurrentQuestion = questions[questionIndex]
        Answers = ArrayList(CurrentQuestion.theAnswer)
        Answers.shuffle()

        Log.d("AnswerGroup", Answers[0] + " " + Answers[1] + " " + Answers[2] + " " + Answers[3])
        Log.d("Answercurrect", CurrentQuestion.theAnswer[0])
    }


    private fun randomQuestion() {
        questions.shuffle()
        SetQuestion()
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_quiz, container, false)
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_quiz, container, false)
        randomQuestion()
        binding.quiz = this
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        Button_1.setOnClickListener {
            chackAnswer(Button_1.text.toString())
        }
        Button_2.setOnClickListener {
            chackAnswer(Button_2.text.toString())
        }
        Button_3.setOnClickListener {
            chackAnswer(Button_3.text.toString())
        }
        Button_4.setOnClickListener {
            chackAnswer(Button_4.text.toString())
        }

        hint_but.setOnClickListener {
            //            //            chackAnswer(CurrentQuestion.theAnswer[0].toString())
//            Log.d("Button1 value :", Button_1.text.toString())
//            Log.d("Button2 value :", Button_2.text.toString())
            if (CurrentQuestion.theAnswer[2] == Button_1.text.toString() || CurrentQuestion.theAnswer[3] == Button_1.text.toString()) {
                Button_1.setBackgroundResource(R.color.colorAccent)
            }
            if (CurrentQuestion.theAnswer[2] == Button_2.text.toString() || CurrentQuestion.theAnswer[3] == Button_2.text.toString()) {
                Button_2.setBackgroundResource(R.color.colorAccent)
            }
            if (CurrentQuestion.theAnswer[2] == Button_3.text.toString() || CurrentQuestion.theAnswer[3] == Button_3.text.toString()) {
                Button_3.setBackgroundResource(R.color.colorAccent)
            }
            if (CurrentQuestion.theAnswer[2] == Button_4.text.toString() || CurrentQuestion.theAnswer[3] == Button_4.text.toString()) {
                Button_4.setBackgroundResource(R.color.colorAccent)
            }
            Log.d("Button3 value :", CurrentQuestion.theAnswer[2].toString())
            Log.d("Button4 value :", CurrentQuestion.theAnswer[3].toString())
            hint_but.visibility = if (view?.visibility == View.VISIBLE) {
                View.INVISIBLE
            } else {
                View.VISIBLE
            }
            usedhint++

        }

    }

    private fun chackAnswer(Answer: String) {
        if (Answer.equals(CurrentQuestion.theAnswer[0])) {
            Scoreall = (Scoreall + 10)
            textscore = (Scoreall).toString()
            Score += 1
        } else {
            Scoreall = (Scoreall - 5)
            textscore = (Scoreall).toString()
        }
        questionIndex++
        if (questionIndex < maxNumberOfQuestion) {
            SetQuestion()
            binding.invalidateAll()
        } else (
                getScore()
                )

    }

    private fun getScore() {
        Log.d("SCORE", Score.toString())
        if (Score >= 7) {
            Navigation.findNavController(view!!).navigate(R.id.action_quizFragment_to_wonFragment)


        } else
            Navigation.findNavController(view!!).navigate(R.id.action_quizFragment_to_lossFragment)
    }


}
